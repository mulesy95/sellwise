// ─── Plan Types ────────────────────────────────────
export type Plan = 'free' | 'starter' | 'growth' | 'studio'

export const PLAN_LIMITS: Record<Plan, {
  monthlyOptimisations: number | null
  competitorAnalysis: boolean
  multiShop: boolean
  apiAccess: boolean
  price: number
}> = {
  free:    { monthlyOptimisations: 3,    competitorAnalysis: false, multiShop: false, apiAccess: false, price: 0 },
  starter: { monthlyOptimisations: 50,   competitorAnalysis: true,  multiShop: false, apiAccess: false, price: 19 },
  growth:  { monthlyOptimisations: null, competitorAnalysis: true,  multiShop: false, apiAccess: false, price: 39 },
  studio:  { monthlyOptimisations: null, competitorAnalysis: true,  multiShop: true,  apiAccess: true,  price: 79 },
}

// ─── AI Output Types ────────────────────────────────
export interface OptimisationResult {
  title: string              // max 140 chars
  tags: string[]             // exactly 13, each max 20 chars
  description: string        // 300–500 chars, first 160 optimised
  keywords: {
    primary: string
    secondary: string[]
    long_tail: string[]
  }
  score: number              // 0–100
  improvements: string[]     // 3–5 actionable tips
}

export interface KeywordResult {
  keyword: string
  volume: 'high' | 'medium' | 'low'
  competition: 'high' | 'medium' | 'low'
  trend: 'rising' | 'stable' | 'falling'
  related: string[]
}

export interface CompetitorAnalysis {
  listing_url: string
  title: string
  tags: string[]
  title_keywords: string[]
  tag_patterns: string[]
  strengths: string[]
  weaknesses: string[]
  beat_version: OptimisationResult
}

export interface AuditResult {
  score: number
  breakdown: {
    title: { score: number; issues: string[] }
    tags: { score: number; issues: string[] }
    description: { score: number; issues: string[] }
  }
  quick_wins: string[]
  optimised_version?: OptimisationResult
}

// ─── API Request/Response Types ─────────────────────
export interface OptimiseRequest {
  title?: string
  description?: string
  category?: string
  style?: string
  material?: string
}

export interface KeywordsRequest {
  seed: string
  category?: string
}

export interface CompetitorRequest {
  url: string
}

export interface AuditRequest {
  title: string
  tags?: string[]
  description?: string
}

// ─── User / Profile Types ───────────────────────────
export interface UserProfile {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  plan: Plan
  usage_count: number
  usage_reset_at: string
  trial_ends_at?: string
  stripe_customer_id?: string
}

export interface UsageStatus {
  used: number
  limit: number | null        // null = unlimited
  isUnlimited: boolean
  percentUsed: number
  canUse: boolean
}
