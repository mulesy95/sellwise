import { createClient } from '@supabase/supabase-js'
import { PLAN_LIMITS } from '../../../shared/types'
import type { Plan, UsageStatus } from '../../../shared/types'

export async function checkUsage(userId: string): Promise<UsageStatus> {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const { data: profile, error } = await supabase
    .from('profiles')
    .select('plan, usage_count, usage_reset_at')
    .eq('id', userId)
    .single()

  if (error || !profile) throw new Error('Profile not found')

  // Reset usage if month has rolled over
  if (new Date(profile.usage_reset_at) <= new Date()) {
    await supabase.from('profiles').update({
      usage_count: 0,
      usage_reset_at: new Date(
        new Date().getFullYear(),
        new Date().getMonth() + 1,
        1
      ).toISOString(),
    }).eq('id', userId)
    profile.usage_count = 0
  }

  const plan = profile.plan as Plan
  const limit = PLAN_LIMITS[plan].monthlyOptimisations
  const used = profile.usage_count

  return {
    used,
    limit,
    isUnlimited: limit === null,
    percentUsed: limit ? Math.round((used / limit) * 100) : 0,
    canUse: limit === null || used < limit,
  }
}

export async function incrementUsage(userId: string): Promise<void> {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  await supabase.rpc('increment', {
    table_name: 'profiles',
    column_name: 'usage_count',
    row_id: userId,
  })
}
