import Anthropic from '@anthropic-ai/sdk'
import type {
  OptimisationResult,
  KeywordResult,
  CompetitorAnalysis,
  AuditResult,
  OptimiseRequest,
} from '../../../shared/types'

const client = new Anthropic()

// ─── System Prompts ─────────────────────────────────

const ETSY_SEO_SYSTEM = `You are an expert Etsy SEO consultant with deep knowledge of the Etsy search algorithm (Cassini). You have helped thousands of sellers rank their listings on the first page of Etsy search.

Your expertise:
- Etsy's algorithm weights: relevancy > recency > conversion rate > reviews > shipping speed
- Title strategy: front-load primary keyword, use natural language, 120–140 chars ideal
- Tag strategy: all 13 tags mandatory, 2–3 word phrases outperform single words, use long-tail
- Description: first 160 chars critical (shown in search snippets), lead with primary benefit
- Buyer psychology: buyers search for occasions, recipients, styles, not just product types
- Current trends: personalised, sustainable, handmade authenticity signals matter

Always respond with valid JSON only. No markdown, no preamble, no explanation outside the JSON.`

const KEYWORD_SYSTEM = `You are an Etsy keyword research specialist. You understand Etsy search volume patterns, seasonal trends, and buyer search behaviour.

Analyse keywords for Etsy specifically — not Google or Amazon. Etsy buyers search differently (gift-oriented, occasion-based, style-focused).

Always respond with valid JSON only. No markdown, no preamble.`

const AUDIT_SYSTEM = `You are an Etsy listing auditor. You evaluate listings against Etsy SEO best practices and provide specific, actionable feedback with scores.

Scoring rubric:
- Title (40 points): keyword placement, length, natural language, specificity
- Tags (35 points): count (13 required), phrase quality, variety, long-tail usage  
- Description (25 points): hook strength, keyword density, benefit-led copy

Always respond with valid JSON only. No markdown, no preamble.`

// ─── Optimisation ────────────────────────────────────

export async function optimiseListing(input: OptimiseRequest): Promise<OptimisationResult> {
  const prompt = `Generate an optimised Etsy listing for this product:

Title: ${input.title || 'Not provided'}
Description: ${input.description || 'Not provided'}
Category: ${input.category || 'Not provided'}
Style: ${input.style || 'Not provided'}
Material: ${input.material || 'Not provided'}

Return JSON matching exactly this schema:
{
  "title": "string (max 140 chars)",
  "tags": ["string (max 20 chars each)", "...13 total"],
  "description": "string (300-500 chars, first 160 chars optimised for search)",
  "keywords": {
    "primary": "string",
    "secondary": ["string", "string", "string"],
    "long_tail": ["string", "string", "string", "string"]
  },
  "score": number (0-100),
  "improvements": ["string", "string", "string"]
}`

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1000,
    system: ETSY_SEO_SYSTEM,
    messages: [{ role: 'user', content: prompt }],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''
  return JSON.parse(text) as OptimisationResult
}

// ─── Keyword Research ────────────────────────────────

export async function researchKeywords(seed: string, category?: string): Promise<KeywordResult[]> {
  const prompt = `Research Etsy keywords for: "${seed}"${category ? ` in category: ${category}` : ''}

Generate 15 related keywords that Etsy buyers actually search for. Include seasonal, occasion-based, and style variations.

Return JSON array:
[
  {
    "keyword": "string",
    "volume": "high" | "medium" | "low",
    "competition": "high" | "medium" | "low",
    "trend": "rising" | "stable" | "falling",
    "related": ["string", "string"]
  }
]`

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1500,
    system: KEYWORD_SYSTEM,
    messages: [{ role: 'user', content: prompt }],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''
  return JSON.parse(text) as KeywordResult[]
}

// ─── Competitor Analysis ─────────────────────────────

export async function analyseCompetitor(
  listingData: { title: string; tags: string[]; description: string; url: string }
): Promise<CompetitorAnalysis> {
  const prompt = `Analyse this Etsy competitor listing and generate a better version:

URL: ${listingData.url}
Title: ${listingData.title}
Tags: ${listingData.tags.join(', ')}
Description: ${listingData.description}

Return JSON:
{
  "listing_url": "string",
  "title": "string",
  "tags": ["string"],
  "title_keywords": ["string"],
  "tag_patterns": ["string"],
  "strengths": ["string"],
  "weaknesses": ["string"],
  "beat_version": { /* full OptimisationResult */ }
}`

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1500,
    system: ETSY_SEO_SYSTEM,
    messages: [{ role: 'user', content: prompt }],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''
  return JSON.parse(text) as CompetitorAnalysis
}

// ─── Listing Audit ───────────────────────────────────

export async function auditListing(input: {
  title: string
  tags?: string[]
  description?: string
}): Promise<AuditResult> {
  const prompt = `Audit this Etsy listing:

Title: ${input.title}
Tags: ${input.tags?.join(', ') || 'Not provided'}
Description: ${input.description || 'Not provided'}

Return JSON:
{
  "score": number (0-100),
  "breakdown": {
    "title": { "score": number (0-40), "issues": ["string"] },
    "tags": { "score": number (0-35), "issues": ["string"] },
    "description": { "score": number (0-25), "issues": ["string"] }
  },
  "quick_wins": ["string", "string", "string"]
}`

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1000,
    system: AUDIT_SYSTEM,
    messages: [{ role: 'user', content: prompt }],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''
  return JSON.parse(text) as AuditResult
}
