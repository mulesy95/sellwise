-- EtsyAI Database Schema
-- Run in Supabase SQL editor or via supabase db push

-- ─── Extensions ────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ─── Users / Profiles ──────────────────────────────
-- Extends Supabase auth.users
create table public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  email text not null,
  full_name text,
  avatar_url text,
  stripe_customer_id text unique,
  plan text not null default 'free' check (plan in ('free', 'starter', 'growth', 'studio')),
  usage_count integer not null default 0,
  usage_reset_at timestamptz not null default (date_trunc('month', now()) + interval '1 month'),
  trial_ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Plan limits view
create table public.plan_limits (
  plan text primary key,
  monthly_optimisations integer, -- null = unlimited
  competitor_analysis boolean default false,
  multi_shop boolean default false,
  api_access boolean default false
);

insert into public.plan_limits values
  ('free',    3,    false, false, false),
  ('starter', 50,   true,  false, false),
  ('growth',  null, true,  false, false),
  ('studio',  null, true,  true,  true);

-- ─── Shops ─────────────────────────────────────────
create table public.shops (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  shop_name text not null,
  shop_url text,
  is_primary boolean default false,
  created_at timestamptz not null default now()
);

-- ─── Optimisations ─────────────────────────────────
create table public.optimisations (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  shop_id uuid references public.shops(id) on delete set null,
  input_title text,
  input_description text,
  input_category text,
  output jsonb not null, -- OptimisationResult schema
  score integer,
  is_saved boolean default false,
  created_at timestamptz not null default now()
);

-- ─── Keyword Lists ─────────────────────────────────
create table public.keyword_lists (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  name text not null,
  seed_keyword text,
  keywords jsonb not null default '[]',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ─── Competitor Analyses ────────────────────────────
create table public.competitor_analyses (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  listing_url text not null,
  extracted_data jsonb,
  analysis jsonb,
  created_at timestamptz not null default now()
);

-- ─── Row Level Security ─────────────────────────────
alter table public.profiles enable row level security;
alter table public.shops enable row level security;
alter table public.optimisations enable row level security;
alter table public.keyword_lists enable row level security;
alter table public.competitor_analyses enable row level security;

-- Users can only access their own data
create policy "Users can view own profile" on public.profiles
  for select using (auth.uid() = id);

create policy "Users can update own profile" on public.profiles
  for update using (auth.uid() = id);

create policy "Users can manage own shops" on public.shops
  for all using (auth.uid() = user_id);

create policy "Users can manage own optimisations" on public.optimisations
  for all using (auth.uid() = user_id);

create policy "Users can manage own keyword lists" on public.keyword_lists
  for all using (auth.uid() = user_id);

create policy "Users can manage own competitor analyses" on public.competitor_analyses
  for all using (auth.uid() = user_id);

-- ─── Functions ──────────────────────────────────────
-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Reset usage count monthly
create or replace function public.reset_monthly_usage()
returns void as $$
begin
  update public.profiles
  set usage_count = 0,
      usage_reset_at = date_trunc('month', now()) + interval '1 month'
  where usage_reset_at <= now();
end;
$$ language plpgsql security definer;

-- ─── Indexes ────────────────────────────────────────
create index idx_optimisations_user_id on public.optimisations(user_id);
create index idx_optimisations_created_at on public.optimisations(created_at desc);
create index idx_keyword_lists_user_id on public.keyword_lists(user_id);
create index idx_shops_user_id on public.shops(user_id);
