# EtsyAI — Project Knowledge Base

## Overview
AI-powered SEO optimiser for Etsy sellers. Generates optimised titles, tags, and descriptions using Claude AI, with keyword research and competitor analysis built in.

**Status**: Speccing / pre-build  
**Target launch**: 6 weeks from start  
**Stack**: Next.js 14 + TypeScript + Tailwind + Supabase + Stripe + Claude API  
**Repo**: github.com/[user]/etsyai  
**Local path**: C:\Dev\Projects\etsyai  

---

## Problem We're Solving
Etsy sellers spend hours writing listings. SEO is opaque — the algorithm rewards specific keyword patterns that sellers don't know. Existing tools (Erank, Marmalead) are stale and not AI-native. Sellers will pay $29–79/mo for something that saves them 2–3 hours per listing and measurably improves search rank.

---

## Target Users
- Etsy sellers with 10–200 active listings
- Non-technical; mobile-first usage likely
- Primary pain: writing titles/tags that actually rank
- Secondary pain: keeping listings fresh after algorithm updates

---

## Core Feature Set (MVP)

### 1. Listing Optimiser (primary feature)
- User pastes a product title or description (or enters product details)
- AI generates: optimised title (140 chars), 13 tags, SEO description (first 160 chars critical)
- Shows keyword score, estimated competition level
- One-click copy of each output

### 2. Keyword Research
- Enter a seed keyword → get related Etsy search terms with volume tiers (high/medium/low)
- Powered by Claude + scraped Etsy autocomplete data
- Save keyword lists per product category

### 3. Competitor Peek
- Enter an Etsy listing URL → extract and analyse their SEO strategy
- Show: keywords used, title structure, tag patterns
- "Beat this listing" — generate a better version

### 4. Listing Audit
- Paste existing listing → get a score (0–100) + specific fixes
- Checks: title length, keyword placement, tag count, description hooks

### 5. Dashboard
- Usage tracking (optimisations used / limit)
- Saved listings history
- Subscription status

---

## Monetisation

### Tiers
| Plan | Price | Limit | Target user |
|------|-------|-------|-------------|
| Free | $0 | 3 optimisations/mo | Trial |
| Starter | $19/mo | 50 optimisations/mo | Part-time sellers |
| Growth | $39/mo | Unlimited + analytics | Full-time sellers |
| Studio | $79/mo | Unlimited + multi-shop + API | Power users / agencies |

### Payment
- Stripe Billing with monthly/annual toggle (annual = 2 months free)
- Free trial: 7 days of Growth, no card required
- Upgrade prompts on usage limit hit

---

## Technical Architecture

### Frontend — Next.js 14 (App Router)
```
/app
  /(auth)
    /login
    /signup
    /forgot-password
  /(dashboard)
    /page.tsx              — dashboard home
    /optimise/page.tsx     — main tool
    /keywords/page.tsx     — keyword research
    /competitor/page.tsx   — competitor analysis
    /audit/page.tsx        — listing audit
    /settings/page.tsx     — account + billing
  /api
    /optimise/route.ts     — calls Claude API
    /keywords/route.ts
    /competitor/route.ts
    /audit/route.ts
    /stripe/webhook/route.ts
```

### Backend / Database — Supabase
```sql
-- Core tables
users (id, email, created_at, stripe_customer_id, plan, usage_count, usage_reset_at)
optimisations (id, user_id, input, output, score, created_at)
keyword_lists (id, user_id, name, keywords jsonb, created_at)
shops (id, user_id, shop_name, shop_url)  -- for multi-shop (Studio tier)
```

### API Layer — Next.js Route Handlers
All AI calls go through `/api/*` route handlers (server-side), never expose Claude API key to client.

### AI — Claude claude-sonnet-4-20250514
- Model: claude-sonnet-4-20250514 (fast, cost-effective for this use case)
- System prompt: specialised Etsy SEO expert persona with current algorithm knowledge
- Structured JSON output for all responses
- Rate limiting: per-user, per-minute limits in middleware

---

## Tech Stack Detail

| Layer | Choice | Reason |
|-------|--------|--------|
| Framework | Next.js 14 (App Router) | Full-stack, great DX, easy Vercel deploy |
| Language | TypeScript | Catches bugs early, better DX |
| Styling | Tailwind CSS | Fast to build, easy to maintain |
| UI Components | shadcn/ui | Accessible, unstyled, composable |
| Database | Supabase (Postgres) | Auth + DB + realtime, generous free tier |
| Payments | Stripe | Industry standard, good docs |
| AI | Anthropic Claude API | Best in class for structured copywriting |
| Deployment | Vercel | Zero-config Next.js, global CDN |
| Email | Resend | Simple API, good deliverability |
| Analytics | Posthog | Product analytics, feature flags |

---

## Environment Variables Required
```env
# Anthropic
ANTHROPIC_API_KEY=

# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Stripe
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_STARTER_PRICE_ID=
STRIPE_GROWTH_PRICE_ID=
STRIPE_STUDIO_PRICE_ID=

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Email (Resend)
RESEND_API_KEY=

# Analytics (Posthog)
NEXT_PUBLIC_POSTHOG_KEY=
```

---

## Build Phases

### Phase 1 — Foundation (Week 1)
- [ ] Next.js project scaffold with TypeScript + Tailwind
- [ ] Supabase project + auth (email/password + Google OAuth)
- [ ] Database schema migrations
- [ ] Basic layout: sidebar nav, dashboard shell
- [ ] Stripe integration + webhook handler
- [ ] Deploy to Vercel (staging)

### Phase 2 — Core AI Features (Week 2–3)
- [ ] Listing Optimiser — UI + API route + Claude prompt
- [ ] Keyword Research — UI + API route
- [ ] Competitor Peek — URL scraper + analysis
- [ ] Listing Audit — scoring logic + display
- [ ] Usage tracking middleware

### Phase 3 — Monetisation (Week 3–4)
- [ ] Pricing page
- [ ] Stripe checkout + customer portal
- [ ] Plan enforcement (usage limits)
- [ ] Upgrade prompts / paywalls
- [ ] 7-day free trial flow

### Phase 4 — Polish + Launch (Week 5–6)
- [ ] Marketing landing page
- [ ] Email sequences (welcome, trial ending, upgrade)
- [ ] Onboarding flow (first listing walkthrough)
- [ ] Error states, loading states, empty states
- [ ] SEO meta tags
- [ ] Production deploy

---

## Claude Prompt Strategy

### Listing Optimiser System Prompt (draft)
```
You are an expert Etsy SEO consultant with deep knowledge of the Etsy search algorithm.
You specialise in writing listing titles, tags, and descriptions that rank highly in Etsy search.

Key rules you follow:
- Titles: 140 chars max, lead with primary keyword, use natural language not keyword stuffing
- Tags: exactly 13 tags, each up to 20 chars, use long-tail phrases not single words
- Descriptions: first 160 chars are critical (shown in search), lead with the main benefit
- Match search intent: buyers search for gifts, occasions, styles — not just product names
- Current Etsy algorithm weights: relevancy > recency > conversion rate > reviews

Always respond in valid JSON matching the schema provided.
```

### Output Schema
```typescript
interface OptimisationResult {
  title: string;           // max 140 chars
  tags: string[];          // exactly 13 items, each max 20 chars
  description: string;     // 300-500 chars, first 160 chars optimised for search
  keywords: {
    primary: string;
    secondary: string[];
    long_tail: string[];
  };
  score: number;           // 0-100 estimated SEO score
  improvements: string[];  // 3-5 specific tips
}
```

---

## Competitor Landscape
| Tool | Weakness | Our edge |
|------|----------|----------|
| Erank | Outdated UI, no AI generation | AI-native, generative not just analytical |
| Marmalead | Expensive ($19+), no AI | Better value, AI-first |
| Sale Samurai | Chrome extension only | Full web app, better UX |
| ChatGPT direct | No Etsy-specific training | Purpose-built prompts, structured output |

---

## Key Metrics to Track
- MRR, churn rate, trial → paid conversion
- Optimisations per user per month (engagement proxy)
- Time to first optimisation (onboarding friction)
- NPS (monthly in-app survey)

---

## Session Log
| Date | Work Done |
|------|-----------|
| 2026-05-12 | Initial ideation, market research, revenue model comparison, full MVP spec created |
